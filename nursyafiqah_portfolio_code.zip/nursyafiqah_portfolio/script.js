// DARK MODE
const themeBtn = document.getElementById("themeBtn");

themeBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");

    // Change the button symbol based on the current theme
    themeBtn.textContent = document.body.classList.contains("dark-mode") ? "☀" : "☾";
});


// TYPING EFFECT
const typingText = "Future Network Computing Professional";
let typingIndex = 0;

function typing() {
    const typingElement = document.getElementById("typing");

    if (typingIndex < typingText.length) {
        typingElement.textContent += typingText.charAt(typingIndex);
        typingIndex++;
        setTimeout(typing, 90);
    }
}

typing();


// CONTACT FORM VALIDATION
const contactForm = document.getElementById("contactForm");

contactForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const message = document.getElementById("message").value.trim();
    const formMessage = document.getElementById("formMessage");

    if (name === "" || email === "" || message === "") {
        formMessage.textContent = "Please fill in all fields.";
        formMessage.style.color = "#d62828";
        return;
    }

    formMessage.textContent = "Thank you! Your form has been validated.";
    formMessage.style.color = "#218838";

    // This is front-end validation only. Connect a form service or backend
    // if you want messages to be delivered to your email.
    contactForm.reset();
});


// PROJECT SEARCH
const searchInput = document.getElementById("search");
const projectCards = document.querySelectorAll(".project-card");

searchInput.addEventListener("input", function () {
    const searchValue = this.value.toLowerCase().trim();

    projectCards.forEach((project) => {
        const projectText = project.textContent.toLowerCase();
        project.style.display = projectText.includes(searchValue) ? "block" : "none";
    });
});


// SCROLL TO TOP AND HEADER SCROLL EFFECT
const topBtn = document.getElementById("topBtn");
const header = document.querySelector("header");

window.addEventListener("scroll", () => {
    // Show or hide the scroll-to-top button
    topBtn.style.display = window.scrollY > 200 ? "block" : "none";

    // Change header appearance when scrolling
    header.classList.toggle("scrolled", window.scrollY > 50);
});

topBtn.addEventListener("click", () => {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});


// AUTOMATIC FOOTER YEAR
document.getElementById("year").textContent = new Date().getFullYear();
